<?php
ini_set('session.gc_maxlifetime', 3600);
session_set_cookie_params(3600);

session_start();

if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = bin2hex(random_bytes(16));
}

$user_id = $_SESSION['user_id'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>19 JUTA LAPANGAN KERJA - DAFTAR SEKARANG!</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comic+Neue:wght@700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="garuda-bg">🦅</div>
    <div class="container">
        <header>
            <div class="flag-stripe red"></div>
            <div class="flag-stripe white"></div>
            <h1>🇮🇩 19 JUTA LAPANGAN KERJA 🇮🇩</h1>
            <p class="subtitle">⚡ JANJI ADALAH UTANG! DAFTAR SEKARANG! ⚡</p>
            <marquee behavior="scroll" direction="left" class="marquee-text">✨ PELUANG EMAS! LAPANGAN KERJA UNTUK SEMUA! BURUAN DAFTAR SEBELUM KEHABISAN! ✨</marquee>
        </header>

        <main>
            <div class="upload-section">
                <h2>📋 FORMULIR PENDAFTARAN KERJA 📋</h2>
                <div class="blink-text" style="text-align: center; margin: 15px 0; font-size: 1.3em;">
                    ⚠️ WAJIB MENGISI DATA DENGAN BENAR! ⚠️
                </div>
                <p class="info">
                    Selamat datang di <strong>Program Nasional 19 Juta Lapangan Kerja</strong>!<br><br>
                    Untuk mendaftar, silakan <strong>UPLOAD FOTO KTP DENGAN FOTO MUKA ANDA</strong>.<br>
                    Pastikan foto terlihat jelas dan tidak buram!<br><br>
                    ⭐ <strong>Format yang diterima: HANYA FILE .JPG</strong> ⭐
                </p>

                <div class="security-badge">
                    <span class="badge">🔐 SISTEM TERENKRIPSI</span>
                    <span class="badge">✅ VALIDASI BERLAPIS</span>
                    <span class="badge">🛡️ AMAN TERPERCAYA</span>
                    <span class="badge">🏆 DIJAMIN PEMERINTAH</span>
                </div>

                <form action="upload.php" method="POST" enctype="multipart/form-data" id="uploadForm">
                    <div class="form-group">
                        <label for="file">📸 UPLOAD FOTO KTP DENGAN FOTO MUKA ANDA (WAJIB .JPG):</label>
                        <input type="file" name="file" id="file" accept=".jpg,.jpeg" required>
                        <small>⚠️ Ukuran maksimal: 1MB | Format: .jpg (File gambar JPEG)</small>
                    </div>

                    <button type="submit" class="btn-submit">
                        🚀 KIRIM LAMARAN SEKARANG! 🚀
                    </button>
                </form>

                <div id="result"></div>
            </div>

            <div class="testimonial">
                <h3>💬 TESTIMONI PESERTA:</h3>
                <div class="quote">
                    <p>"Alhamdulillah setelah upload KTP langsung dapat kerja! Terima kasih Mas Gibran!" - Budi, Jakarta</p>
                    <p>"Prosesnya cepat, gak pake ribet. 5 bintang!" - Siti, Surabaya</p>
                    <p>"Awalnya skeptis, tapi ternyata beneran dapat pekerjaan!" - Ahmad, Bandung</p>
                </div>
            </div>
        </main>

        <footer>
            <div class="footer-marquee">
                <marquee behavior="scroll" direction="right">🎉 JANGAN LEWATKAN KESEMPATAN EMAS INI! DAFTAR SEKARANG JUGA! 🎉</marquee>
            </div>
            <p>© 2025 Program 19 Juta Lapangan Kerja</p>
            <p style="font-size: 0.8em; color: #666; margin-top: 5px;">*Syarat dan ketentuan berlaku</p>
        </footer>
    </div>

    <script src="assets/js/main.js"></script>
</body>
</html>
