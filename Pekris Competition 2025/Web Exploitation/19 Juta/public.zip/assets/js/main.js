/**
 * 19 Juta Lapangan Kerja - Client-side JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    const uploadForm = document.getElementById('uploadForm');
    const fileInput = document.getElementById('file');
    
    // File input change handler
    if (fileInput) {
        fileInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                console.log('File selected:', file.name);
                console.log('File size:', (file.size / 1024).toFixed(2) + ' KB');
                console.log('File type:', file.type);
                
                const maxSize = 5 * 1024 * 1024; // 5MB
                if (file.size > maxSize) {
                    alert('File too large! Maximum size is 5MB.');
                    fileInput.value = '';
                    return;
                }
            }
        });
    }
    
    // Form submit handler
    if (uploadForm) {
        uploadForm.addEventListener('submit', function(e) {
            const file = fileInput.files[0];
            if (!file) {
                e.preventDefault();
                alert('Please select a file to upload.');
                return;
            }
            
            const submitBtn = uploadForm.querySelector('.btn-submit');
            submitBtn.textContent = '⏳ Uploading...';
            submitBtn.disabled = true;
        });
    }
    
    // Add animation to security badges
    const badges = document.querySelectorAll('.badge');
    badges.forEach((badge, index) => {
        badge.style.animation = `fadeInUp 0.5s ease ${index * 0.1}s both`;
    });
});

const style = document.createElement('style');
style.textContent = `
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
`;
document.head.appendChild(style);
