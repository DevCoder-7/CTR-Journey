<?php
ini_set('session.gc_maxlifetime', 3600);
session_set_cookie_params(3600);

session_start();

if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = bin2hex(random_bytes(16));
}

$user_id = $_SESSION['user_id'];

define('BASE_UPLOAD_DIR', __DIR__ . '/uploads/');
define('UPLOAD_DIR', BASE_UPLOAD_DIR . $user_id . '/');
define('MAX_FILE_SIZE', 1 * 1024 * 1024);
define('MAX_FILES_PER_SESSION', 10);
define('FLAG_LOCATION', '/flag.txt');

if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    
    $file_count = count(glob(UPLOAD_DIR . '*'));
    if ($file_count >= MAX_FILES_PER_SESSION) {
        respondError("❌ Maksimal " . MAX_FILES_PER_SESSION . " file per session!<br><small>Anda sudah terlalu banyak upload file!</small>");
    }
    
    $file = $_FILES['file'];
    $filename = basename($file['name']);
    $tmp_name = $file['tmp_name'];
    $file_size = $file['size'];
    $file_error = $file['error'];
    
    if ($file_error !== UPLOAD_ERR_OK) {
        respondError("❌ Upload gagal dengan kode error: " . $file_error . "<br>Silakan coba lagi!");
    }
    
    if ($file_size > MAX_FILE_SIZE) {
        respondError("❌ File terlalu besar! Ukuran maksimal adalah " . (MAX_FILE_SIZE / 1024 / 1024) . "MB<br>Foto KTP Anda terlalu HD!");
    }
    
    $content = file_get_contents($tmp_name);
    
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    
    if (strpos($filename, '.') === 0 && strpos($filename, '.', 1) === false) {
        $extension = '';
    }
    

    $blocked_extensions = [
        'php', 'phtml', 'php3', 'php4', 'php5', 'php7', 
        'phar', 'pht', 'phps', 'inc', 'sh', 'cgi', 'pl'
    ];
    
    if (in_array($extension, $blocked_extensions)) {
        respondError("❌ Extension '.$extension' is blocked for security reasons!");
    }
    
    
    foreach ($blocked_extensions as $blocked) {
        if (stripos($filename, '.' . $blocked) !== false) {
            respondError("❌ Filename contains blocked pattern: .$blocked");
        }
    }
    
    $allowed_extensions = ['jpg', 'jpeg'];
    
    if ($extension !== '' && !in_array($extension, $allowed_extensions)) {
        respondError(
            "❌ Hanya file .JPG yang diperbolehkan!<br>" .
            "Silakan upload foto KTP Anda dalam format JPEG (.jpg)<br>" .
            "<small>Ini bukan tempat upload meme!</small>"
        );
    }
    
    if ($extension !== '') {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $tmp_name);
        finfo_close($finfo);
        
        $allowed_mimes = ['image/jpeg', 'image/png', 'image/gif'];
        
        if (!in_array($mime, $allowed_mimes)) {
            respondError(
                "❌ Tipe file tidak valid!<br>" .
                "Tipe MIME yang terdeteksi: <code>$mime</code><br>" .
                "Hanya file gambar valid (JPEG, PNG, GIF) yang diterima.<br>" .
                "<small>Jangan upload file aneh-aneh ya!</small>"
            );
        }
    }
    
    if (strlen($filename) > 255) {
        respondError("❌ Nama file terlalu panjang! Maksimal 255 karakter!");
    }
    
    if (strpos($filename, "\0") !== false) {
        respondError("❌ Nama file tidak valid! Jangan coba hack ya!");
    }
    
    $safe_filename = $filename;
    
    $upload_path = UPLOAD_DIR . $safe_filename;
    
    if (move_uploaded_file($tmp_name, $upload_path)) {
        chmod($upload_path, 0644);
        
        $file_url = 'uploads/' . $user_id . '/' . urlencode($safe_filename);
        
        respondSuccess(
            "✅ File berhasil diupload!<br>" .
            "Nama file: <code>" . htmlspecialchars($safe_filename) . "</code><br>" .
            "Lokasi: <a href='" . $file_url . "' target='_blank'>Lihat File</a><br>" .
            "<small>Ukuran file: " . formatBytes($file_size) . "</small><br><br>" .
            "<em>Terima kasih telah mendaftar! Mohon tunggu panggilan interview (maksimal 100 tahun)</em>"
        );
    } else {
        respondError("❌ Gagal menyimpan file. Silakan coba lagi!<br><small>Server sedang sibuk melayani 19 juta pelamar</small>");
    }
    
} else {
    respondError("❌ Metode request tidak valid atau tidak ada file yang diupload!<br><small>Baca petunjuk dengan teliti!</small>");
}

function respondSuccess($message) {
    echo '
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <title>Upload Berhasil!</title>
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
        <div class="garuda-bg">🦅</div>
        <div class="container">
            <div class="result-box success">
                <h2>✅ SUKSES!</h2>
                <p>' . $message . '</p>
                <a href="index.php" class="btn-back">← Kembali ke Form Pendaftaran</a>
            </div>
        </div>
    </body>
    </html>
    ';
    exit;
}

function respondError($message) {
    echo '
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <title>Upload Gagal</title>
        <link rel="stylesheet" href="assets/css/style.css">
    </head>
    <body>
        <div class="garuda-bg">🦅</div>
        <div class="container">
            <div class="result-box error">
                <h2>❌ UPLOAD GAGAL!</h2>
                <p>' . $message . '</p>
                <a href="index.php" class="btn-back">← Coba Lagi</a>
            </div>
        </div>
    </body>
    </html>
    ';
    exit;
}

function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= (1 << (10 * $pow));
    return round($bytes, $precision) . ' ' . $units[$pow];
}
?>
