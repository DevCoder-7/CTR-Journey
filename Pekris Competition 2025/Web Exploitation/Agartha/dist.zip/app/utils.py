def make_response(status="success", data=None, error=None):
    return {
        "status": status,
        "data": data,
        "error": error,
    }