const { Builder } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const CONFIG = {
    APPNAME: process.env['APPNAME'] || "Admin",
    APPURL: process.env['APPURL'] || "http://172.17.0.1",
    APPURLREGEX: process.env['APPURLREGEX'] || "^.*$",
    APPFLAG: process.env['APPFLAG'] || "dev{flag}",
    APPLIMITTIME: Number(process.env['APPLIMITTIME'] || "60000"),
    APPLIMIT: Number(process.env['APPLIMIT'] || "5"),
    APPEXTENSIONS: (() => {
        const extDir = path.join(__dirname, 'extensions');
        const dir = [];
        try {
            fs.readdirSync(extDir).forEach(file => {
                if (fs.lstatSync(path.join(extDir, file)).isDirectory()) {
                    dir.push(path.join(extDir, file));
                }
            });
        } catch (e) {
            // extensions directory doesn't exist or is empty
        }
        return dir;
    })()
};

console.table(CONFIG);

let chromedriverProcess = null;

function startChromeDriverService() {
    chromedriverProcess = spawn('chromedriver', [
        '--port=9515',
        '--allowed-origins=*',
        '--allowed-ips=',       
        '--verbose'
    ]);

    chromedriverProcess.stdout.on('data', (data) => {
        console.log(`ChromeDriver: ${data}`);
    });

    chromedriverProcess.stderr.on('data', (data) => {
        console.error(`ChromeDriver: ${data}`);
    });

    chromedriverProcess.on('close', (code) => {
        console.log(`ChromeDriver process exited with code ${code}`);
    });
}

startChromeDriverService();

function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

function getChromeOptions() {
    const options = new chrome.Options();
    
    const is_x11_exists = fs.existsSync('/tmp/.X11-unix');
    if (process.env['DISPLAY'] === undefined || !is_x11_exists) {
        options.addArguments('--headless=new');
    }
    
    options.addArguments(
        '--disable-dev-shm-usage',
        '--disable-gpu',
        '--no-gpu',
        '--disable-default-apps',
        '--disable-translate',
        '--disable-device-discovery-notifications',
        '--disable-software-rasterizer',
        '--disable-xss-auditor',
        '--no-sandbox',
        '--disable-setuid-sandbox'
    );
    
    if (CONFIG.APPEXTENSIONS.length > 0) {
        CONFIG.APPEXTENSIONS.forEach(extPath => {
            options.addExtensions(extPath);
        });
    }
    
    return options;
}

module.exports = {
    name: CONFIG.APPNAME,
    urlRegex: CONFIG.APPURLREGEX,
    rateLimit: {
        windowMs: Number(CONFIG.APPLIMITTIME) * 1000,
        limit: Number(CONFIG.APPLIMIT)
    },
    bot: async (urlToVisit) => {
        let driver = null;
        try {
            driver = await new Builder()
                .forBrowser('chrome')
                .setChromeOptions(getChromeOptions())
                .usingServer('http://localhost:9515')
                .build();

            await driver.get(CONFIG.APPURL);
            await driver.manage().addCookie({
                name: 'flag',
                value: CONFIG.APPFLAG,
                path: '/'
            });

            console.log(`bot visiting ${urlToVisit}`);
            
            await driver.get(urlToVisit);
            
            await sleep(15000);

            console.log("browser close...");
            return true;
        } catch (e) {
            console.error(e);
            return false;
        } finally {
            if (driver) {
                await driver.quit();
            }
        }
    },
    cleanup: () => {
        if (chromedriverProcess) {
            chromedriverProcess.kill();
        }
    }
};

process.on('SIGINT', () => {
    if (chromedriverProcess) {
        chromedriverProcess.kill();
    }
    process.exit();
});

process.on('SIGTERM', () => {
    if (chromedriverProcess) {
        chromedriverProcess.kill();
    }
    process.exit();
});